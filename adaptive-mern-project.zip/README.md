
# Adaptive MERN Demo

This is a generated scaffold. Replace frontend/src/App.jsx with your full React component from the canvas, then run frontend and backend.

Run frontend locally:
```
cd frontend
npm install
npm run start
```

Run backend locally:
```
cd backend
npm install
npm run start
```

