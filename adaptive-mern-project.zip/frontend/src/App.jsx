import React from 'react';
export default function App(){ return (<div style={{padding:20}}><h1>Adaptive MERN Demo (placeholder)</h1><p>Replace this file with your full React component.</p></div>)}